
<?php $__env->startSection('title', 'Read Book'); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-index container-index">
        <div class="container">
            <div class="row row-index">
                
                <div class="col col-index">
                    <h1 class="text-white">Livros Lidos</h1>
                    <p class="text-white">Cadastre os livros que você leu ou está lendo para manter um controle de todas as informações dos livros lidos por você.</p>
                    <a href="/register" class="btn btn-outline-light">Criar Conta</a>
                </div>
                <div class="col col-index">
                    <img src="../img/read_book_livro.png" height="800" srcset="">
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joao\Projetos Laravel\tempo_leitura\resources\views/index.blade.php ENDPATH**/ ?>