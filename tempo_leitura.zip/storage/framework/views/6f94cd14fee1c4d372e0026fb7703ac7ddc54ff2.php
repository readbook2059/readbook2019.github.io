
<?php
  $userController = new App\Http\Controllers\UserController();
  $isAdmin =  $userController->isAdmin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="shortcut icon" href="../img/estante_icon.png" type="image/x-icon">
    <?php echo app('Illuminate\Foundation\Vite')([
            'resources/js/app.js',
            'resources/css/app.css',
            'node_modules/bootstrap/dist/css/bootstrap.min.css',
            'node_modules/bootstrap/dist/js/bootstrap.bundle.js'    
    	]); ?>
</head>
<body>
  
  <main>
      <nav class="navbar navbar-expand-lg navbar-dark bg-blue">
          <div class="container-fluid">
            <a class="navbar-brand" href="/"><img src="../img/estante_icon.png" height="50" class="log-menu"> Read Book</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li>
                <?php if(auth()->check()): ?> 
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Livros
                  </a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="/livros">Meus livros</a></li>
                    <li><a class="dropdown-item" href="/criar">Cadastrar livro</a></li>
                  </ul>
                </li>

                <?php if($isAdmin): ?>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Gerenciar
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="/admins">Administradores</a></li>
                      <li><a class="dropdown-item" href="/users">Usuários</a></li>
                    </ul>
                  </li>
                <?php endif; ?>
                
                <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="/conta">Conta</a>
                </li>
                <?php endif; ?>
              </ul>
                
                  <?php if(auth()->check()): ?> 
                    <form class="d-flex" method="GET" action="/pesquisa"> 
                      <?php echo csrf_field(); ?>
                      <input class="form-control me-2" type="search" id="livro" name="livro" placeholder="Nome do Livro" aria-label="Search">
                      <button class="btn btn-outline-blue" type="submit">Pesquisar</button>
                    </form>

                  <?php else: ?>
                    <div class="d-flex">
                      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                          <a class="nav-link" aria-current="page" href="/register"><Button class="btn btn-criar-conta">Criar Conta</Button></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" aria-current="page" href="/login"><Button class="btn btn-fazer-login">Fazer Login</Button></a>
                        </li>
                      </ul>
                    </div>
                  <?php endif; ?>
            </div>
          </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="js/app.js"></script>
</body>
</html><?php /**PATH C:\Users\Joao\Projetos Laravel\tempo_leitura\resources\views/layouts/main.blade.php ENDPATH**/ ?>