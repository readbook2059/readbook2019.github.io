
<?php $__env->startSection('title', 'Pagina principal'); ?>

<?php $__env->startSection('content'); ?>

<script>
    function confirmDelete(delUrl) {
        if (confirm("Deseja apagar o livro? Não é possivel recuperar.")) {
            document.location = delUrl;
        }  
    }
</script>

    <div class="container">
         <!-- NOTIFICACAO DE EDIÇÃO -->
         <?php
         if(isset($erro)){ 
            if($erro == 0){ ?> 
                <!-- MENSAGEM DE CONTA CRIADA-->
                <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: -50px!important;margin-bottom: 50px!important;">
                    <strong>Livro editado com sucesso!</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

            <!-- MENSAGEM DE CONTA NÃO CRIADA-->
            <?php }else{ ?>
                <div class="alert alert-danger alert-dismissible fade show " role="alert" style="margin-top: -50px!important;margin-bottom: 50px!important;">
                    <strong>Não foi possível editar o livro.</strong> Tente novamente mais tarde.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php }
        } ?>


        <div class="row">
            <div class="col-4">
                <div class="div-img-livro-selecionado" <?php if($livro->img_livro == null): ?>style="background-image: url('../img/book_transparent.png');" <?php endif; ?>>
                    
                    <?php if($livro->img_livro): ?>
                        <img src="<?php echo e($livro->img_livro); ?>"  class="img-livro-selecionado">
                    <?php endif; ?>

                    <?php if($livro->img_livro == null): ?>
                        <h1><?php echo e($livro->nome_livro); ?></h1>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-8 col-info-livro">
                <h1 class="nome-livro-lido"><?php echo e($livro->nome_livro); ?></h1>
                <p><?php echo e($livro->descricao_livro); ?></p>
                           
           
                
                <div class="row row-livro-lido">
                    <div class="col">
                        <h3>Tempo lido: <?php echo e($livro->tempo_lido); ?></h3>
                        <h3>Páginas Lidas: <?php echo e($livro->paginas_lidas); ?> / <?php echo e($livro->total_paginas); ?></h3>
                        <h3>Terminou: <?php echo e($livro->lido); ?></h3>
                        <h3>Data de inicio: <?php echo e($livro->data_inicio); ?></h3>
                        <?php if($livro->data_termino): ?>
                            <h3>Data de término: <?php echo e($livro->data_termino); ?></h3>
                        <?php endif; ?>
                    </div>
                    <div class="col col-livro-lido">
                        <a href="/editar/<?php echo e($livro->id_livro); ?>" class="btn btn-outline-primary">Editar</a>
                        <a onclick="confirmDelete('/excluir/<?php echo e($livro->id_livro); ?>')"   class="btn btn-outline-danger">Excluir</a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joao\Projetos Laravel\tempo_leitura\resources\views/books/consultar_livro.blade.php ENDPATH**/ ?>