
<?php $__env->startSection('title', 'Pagina principal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
            </div>

            <?php if($_GET['livro']): ?>
                <?php if(count($livros)): ?>
                    <h1 class="text-center titulo-livros">Livros com: "<?php echo e($_GET['livro']); ?>"</h1>
                <?php else: ?>
                <h1 class="text-center titulo-livros">Nenhum livro encontrado com: "<?php echo e($_GET['livro']); ?>"</h1>
                <?php endif; ?>
            <?php else: ?>
                <h1  class="text-center titulo-livros">Meus livros</h1>
            <?php endif; ?>

            <?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col col-livro">
                    <a href="/livro?id=<?php echo e($livro->id_livro); ?>">
                        <div class="livro" style="background-image:url('<?php echo e($livro->img_livro); ?>');">
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joao\Projetos Laravel\tempo_leitura\resources\views/books/pesquisar_livro.blade.php ENDPATH**/ ?>