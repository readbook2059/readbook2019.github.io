
<?php $__env->startSection('title', 'Pagina principal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
            <form class="form-cadastrar-livro" action="/update" method="post">
                <?php echo csrf_field(); ?>
                <h1 class="text-center">Cadastre um Livro</h1>

                <input class="d-none" type="text" name="id_livro" id="id_livro" value="<?php echo e($livro->id_livro); ?>">
                <div class="mb-3">
                  <label for="nome_livro" class="form-label">Nome do Livro</label>
                  <input type="text" class="form-control <?php $__errorArgs = ['nome_livro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nome_livro" name="nome_livro" value="<?php echo e($livro->nome_livro); ?>">

                  <?php $__errorArgs = ['nome_livro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label data-label-image class="form-label">Capa do Livro
                        <input type="file" class="d-none" data-input-image id="img_livro" name="img_livro" value="<?php echo e($livro->img_livro); ?>">
                        <input class="d-none" id="img_livro" name="img_livro" type="text" value="<?php echo e($livro->img_livro); ?>">
                        <div class="img-escolher-capa" style="background-image: url('<?php echo e($livro->img_livro); ?>')">
                            <img data-image-preview height="300px" width="200px" class="img-escolher-capa">
                        </div>
                    </label>
                </div>

                <div class="mb-4">
                    <label for="lido" class="form-label">Terminou o Livro</label>
                    <input type="text" class="form-control" id="lido" name="lido" value="<?php echo e($livro->lido); ?>">
                </div>

                <div class="mb-4">
                    <label for="total_paginas" class="form-label">Total de Páginas</label>
                    <input type="text" class="form-control" id="total_paginas" name="total_paginas" value="<?php echo e($livro->total_paginas); ?>">
                </div>

                <div class="mb-4">
                    <label for="tempo_lido" class="form-label">Tempo lido</label>
                    <input type="text" class="form-control" id="tempo_lido" name="tempo_lido" value="<?php echo e($livro->tempo_lido); ?>">
                </div>

                <div class="mb-4">
                    <label for="paginas_lidas" class="form-label">Páginas Lidas</label>
                    <input type="text" class="form-control" id="paginas_lidas" name="paginas_lidas" value="<?php echo e($livro->paginas_lidas); ?>">
                </div>

                <div class="mb-4">
                    <div class="row">
                        <div class="col">
                            <label for="data_inicio" class="form-label">Data de inicio da leitura</label>
                            <input id="data_inicio" name="data_inicio" placeholder="06/06/2023" value="<?php echo e($livro->data_inicio); ?>"" type="text" class="form-control">
        
                            <?php $__errorArgs = ['nome_livro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <label for="data_termino" class="form-label">Data de término</label>
                            <input id="data_termino" name="data_termino" placeholder="Termino da leitura" value="<?php echo e($livro->data_termino); ?>"" type="text" class="form-control">
        
                            <?php $__errorArgs = ['nome_livro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="mb-3 ">
                    <label for="descricao_livro" class="form-label">Descrição do Livro</label>
                    <textarea class="form-control" id="descricao_livro" name="descricao_livro" rows="3"><?php echo e($livro->descricao_livro); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Atualizar</button>
                
            </div>
        </form>
    </div>
    <script src="js\preview_image.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joao\Projetos Laravel\tempo_leitura\resources\views/books/editar.blade.php ENDPATH**/ ?>