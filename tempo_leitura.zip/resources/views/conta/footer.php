<footer>
    Desenvolvido pelo João Enrique
</footer>