@extends('layouts.main')
@section('title', 'Página não encontrada')

@section('content')
    <section style="display: grid; justify-content: center;">
        <img height="700" src="../img/page-not-found.jpg" alt="" srcset="">
    </section>
@endsection